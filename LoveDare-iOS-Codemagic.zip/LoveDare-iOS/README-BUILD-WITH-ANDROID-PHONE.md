# LoveDare iOS — build tanpa Mac

Project ini sudah disiapkan untuk cloud build menggunakan Codemagic.

## Yang bisa dilakukan gratis
1. Upload repository ini ke GitHub dari HP Android.
2. Hubungkan repository ke Codemagic.
3. Jalankan workflow `ios_unsigned_build`.
4. Jika berhasil, berarti project iOS dan source game berhasil dikompilasi di macOS cloud.

## Penting tentang instalasi iPhone
Workflow di atas sengaja unsigned. Ini untuk menguji bahwa project dapat dibuild tanpa Mac.
Untuk membuat IPA yang ditandatangani dan dapat didistribusikan ke perangkat/tester, diperlukan Apple signing credentials dan keanggotaan Apple Developer Program sesuai metode distribusi yang dipilih.

## Bundle ID
`com.clipvik.lovedare`

Jika ID ini sudah dipakai oleh aplikasi lain di Apple Developer account, ubah ke ID unik milik sendiri sebelum signed build.
