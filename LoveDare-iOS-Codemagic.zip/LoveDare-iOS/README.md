# Love Dare — iOS Project

This project wraps the supplied Love Dare HTML/CSS/JavaScript game in a native iOS app using Apple's WKWebView.

## Project contents
- `LoveDare.xcodeproj` — open this in Xcode on a Mac.
- `LoveDare/LoveDareApp.swift` — native iOS entry point and WKWebView wrapper.
- `LoveDare/GameResources/` — original game source copied from the supplied ZIP.
- `LoveDare/Assets.xcassets/` — app icon assets generated from the supplied icon.
- `LoveDare/Info.plist` — iOS app configuration, portrait orientation.

## Build
1. Open `LoveDare.xcodeproj` in Xcode.
2. Select an iPhone simulator or a connected iPhone.
3. Select the `Love Dare` target.
4. Set your Apple Developer Team/signing settings under Signing & Capabilities.
5. Build and run.

The game is loaded from the app bundle, not from a website URL. `WKWebView` is Apple's current web-content view for this purpose.

## Important
The original game references Google Fonts. If the device is offline, those remote fonts may not load. The game itself and its local assets remain bundled in the app.

This project is a buildable starting point; App Store/TestFlight/ad-hoc distribution still requires Apple's signing and distribution process.
